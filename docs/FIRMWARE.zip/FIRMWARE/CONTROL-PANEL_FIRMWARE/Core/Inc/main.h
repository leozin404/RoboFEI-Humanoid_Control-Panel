/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32u5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BTTN2_Pin GPIO_PIN_2
#define BTTN2_GPIO_Port GPIOA
#define BTTN1_Pin GPIO_PIN_3
#define BTTN1_GPIO_Port GPIOA
#define OVERLOAD_Pin GPIO_PIN_4
#define OVERLOAD_GPIO_Port GPIOA
#define COMM_BOARD_Pin GPIO_PIN_5
#define COMM_BOARD_GPIO_Port GPIOA
#define GAMECONTROLLER_Pin GPIO_PIN_6
#define GAMECONTROLLER_GPIO_Port GPIOA
#define LOCALIZATION_Pin GPIO_PIN_7
#define LOCALIZATION_GPIO_Port GPIOA
#define CAM_Pin GPIO_PIN_0
#define CAM_GPIO_Port GPIOB
#define IMU_Pin GPIO_PIN_1
#define IMU_GPIO_Port GPIOB
#define ROBOT_BRINGUP_Pin GPIO_PIN_2
#define ROBOT_BRINGUP_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
